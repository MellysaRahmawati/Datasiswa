<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Resume - Start Bootstrap Theme</title>
        <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
            <a class="navbar-brand js-scroll-trigger" href="#page-top">
                <span class="d-block d-lg-none">Clarence Taylor</span>
                <span class="d-none d-lg-block"><img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="assets/img/images.jpg" alt="..." /></span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="index.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="DataSiswa.php">Data Siswa</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="Login.php">Login/Logout</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="Kejuruan.php">Kejuruan</a></li>
                    
                </ul>
            </div>
        </nav>
        <!-- Page Content-->
        <div class="container-fluid p-0">
            <!-- About-->
            <section class="resume-section" id="about">
                <div class="resume-section-content">
                    <h1 class="mb-0">
                        Data Siswa
                        <span class="text-primary">Smk 8 Surakarta</span>
                    </h1>
                    <h2>Seni Karawitan</h2>
                    <img src="seni karawitan.jpg" width="800" height="400">
                    <h3>Mempelajari berbagai instrumen musik tradisional seperti suling, kecapi, rabab, gamelan, dan gendang. Tidak hanya belajar memainkan alat musik, kamu juga akan belajar teknik vokal dalam musik tradisional, khususnya lagi “nyinden”.</h3>
                    <h2>Seni Tari</h2>
                    <img src="seni tari.jpg" width="800" height="400">
                    <h3>Suatu gerakan semua bagian tubuh atau hanya sebagian saja yang dilakukan dengan ritmis serta pada waktu tertentu untuk mengungkap pikiran,perasaan,dan tujuan dengan iringan musik atau tanpa iringan musik.</h3>
                    <h2>Seni Pendalangan</h2>
                    <img src="seni pendalangan.jpg" width="800" height="400">
                    <h3>Seni yang mengandung nilai hidup dan kehidupan luhur,yang dalam setiap akhir cerita/lakonnya selalu memenangkan kebaikan dan mengalahan kejahatan.</h3>
                    <h2>Seni Musik</h2>
                    <img src="seni musik.jpg" width="800" height="400">
                    <h3>Karya seni berupa bunyi yang dituangkan dalam bentuk lagu atau komposisi sebagian ungkapan perasaan dan pikiran penciptanya melalui unsur-unsur pokok musik.</h3>
                    <h2>Multimedia</h2>
                    <img src="multimedia.jpg" width="800" height="400">
                    <h3>Kombinasi dari paling sedikit dua media input atau output dari data,media ini daopat audio(suara,musik),animasi video,teksgrafik dan gambar.</h3>
                    <h2>Program Televisi dan Filim</h2>
                    <img src="program televisi dan filim.jpg" width="800" height="400">
                    <h3>Bidang ilmu yang mempelajari bagaimana menciptakan bentuk-bentuk didalam audio visual lengkap dengan berbagai prosesnya.</h3>          
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
