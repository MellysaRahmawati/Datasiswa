<?php 

$host = "localhost";
$user = "root";
$pass = "";
$db = "smk8surakarta";

$dbconnect = new mysqli ( "$host", "$user", "$pass", "$db" );


 
 ?>