<?php

include 'koneksi.php';

$namasiswa= $_POST['namasiswa'];
$kelas= $_POST['kelas'];
$jurusan= $_POST['jurusan'];


 mysqli_query($dbconnect, "INSERT INTO `datasiswa` (`nis`, `nama_siswa`, `kelas`, `jurusan`) VALUES ('$nis', '$namasiswa', '$kelas', '$jurusan')");

 header("location:datasiswa.php")
 ?>
