<?php

 include 'koneksi.php';
  $nis = $_POST['nis'];
  $namasiswa = $_POST['nama_siswa'];
  $kelas = $_POST['kelas'];
  $jurusan = $_POST['jurusan'];



  mysqli_query($dbconnect, "UPDATE `datasiswa` SET `nama_siswa`='$namasiswa', `kelas`='$kelas' , `jurusan`='$jurusan' WHERE `datasiswa`.`nis`='$nis' ");
  header("location:datasiswa.php");
  ?>