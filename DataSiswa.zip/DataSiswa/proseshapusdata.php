<?php include 'koneksi.php';

$nis = $_GET['nis'];


mysqli_query($dbconnect, "DELETE FROM datasiswa WHERE nis = '$nis' "); 


header("location:datasiswa.php");
?>